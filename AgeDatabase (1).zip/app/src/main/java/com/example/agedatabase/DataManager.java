package com.example.agedatabase;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class DataManager {


    private SQLiteDatabase mDB;
    static String TABLE_ROW_ID = "_id";
    static String TABLE_ROW_NAME = "name";
    static String TABLE_ROW_AGE = "age";
    static final String DB_NAME = "address_book_db";
    static final int DB_VERSION = 1;
    static final String TABLE_N_AND_A = "names_and_adresses";

    public DataManager(Context context) {

        CustomSQLiteOpenHelper helper = new CustomSQLiteOpenHelper(context);

        mDB = helper.getWritableDatabase();
    }


    // This class is created when our DataManager is initialized
    private class CustomSQLiteOpenHelper extends SQLiteOpenHelper {
        public CustomSQLiteOpenHelper(Context context) {
            super(context, DB_NAME, null, DB_VERSION);
        }

        public void onCreate(SQLiteDatabase db) {
            String newTableQueryString = "CREATE TABLE "
                    + TABLE_N_AND_A + " ("
                    + TABLE_ROW_ID + " INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,"
                     + TABLE_ROW_NAME + " TEXT NOT NULL,"
                    + TABLE_ROW_AGE + " TEXT NOT NULL);";
            db.execSQL(newTableQueryString);
        }

        @Override
        public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

        }
    }


    public void insert(String name, String age) {
        // Add all the details to the table
        String query = "INSERT INTO " + TABLE_N_AND_A + " (" +
                TABLE_ROW_NAME + ", "
                + TABLE_ROW_AGE + ") " +
                "VALUES (" + "'" + name + "'" + ", " + "'" + age + "'" + ");";
        Log.i("insert() = ", query);
        mDB.execSQL(query);
    }

    public void delete(String name) {

        String query = "DELETE FROM " + TABLE_N_AND_A +
                " WHERE " + TABLE_ROW_NAME +
                " = '" + name + "';";
        Log.i("delete() = ", query);
        mDB.execSQL(query);

    }


    public Cursor selectAll() {
        Cursor c = mDB.rawQuery("SELECT *" + " from " +
                TABLE_N_AND_A, null);
        return c;
    }

    public Cursor searchName(String name) {
        String query = "SELECT *" +
                " from " +
                TABLE_N_AND_A + " WHERE " +
                TABLE_ROW_NAME + " = '" + name + "';";

        Log.i("searchName() = ", query);
        Cursor c = mDB.rawQuery(query, null);
        return c;
    }


}
